import json_lines
import os
import csv

def get_data_in_csv():
    max_no_of_retweet = 1
    retweet_no_list = [0,0,0,0,0,0,0]
    tweets = []
    who_tweeted = []
    i=1
    with open('tweets.csv','w',newline='',encoding='utf-8')as fcsv:
        writer = csv.writer(fcsv, delimiter=';')
        list = ['tweet_id','tweeted_by','tweeted_at','no_of_followers_of_who_tweeted','no_of_retweet','tweet_text']
        writer.writerow(list)
        with open("result.jsonl", 'rb') as fjson:  # opening file in binary(rb) mode
            for item in json_lines.reader(fjson, broken=True):
                #print(i)
                if item.get('retweeted_status', None)!=None:
                    #print(i)
                    #i =i+1
                    tweet_id = item['retweeted_status']['id']
                    user = item['retweeted_status']['user']['id']
                    tweeted_at = item['retweeted_status']['created_at']
                    no_of_folowers = item['retweeted_status']['user']['followers_count']
                    retweet_count = item['retweeted_status']['retweet_count']
                    text = item['retweeted_status']['text'].replace('\n','').replace('\r','')

                    list1 = [tweet_id,user,tweeted_at,no_of_folowers,retweet_count,text]
                    writer.writerow(list1)
                    '''
                    if(retweet_count<=100):
                        retweet_no_list[0] = retweet_no_list[0]+1
                    elif (100<retweet_count<=300):
                        retweet_no_list[1] = retweet_no_list[1] + 1
                    elif (300<retweet_count <=600):
                        retweet_no_list[2] = retweet_no_list[2] + 1
                    elif (600<retweet_count <= 1000):
                        retweet_no_list[3] = retweet_no_list[3] + 1
                    elif (1000<retweet_count <= 1500):
                        retweet_no_list[4] = retweet_no_list[4] + 1
                    elif (1500<retweet_count <= 2000):
                        retweet_no_list[5] = retweet_no_list[5] + 1
                    else:
                        retweet_no_list[6] = retweet_no_list[6] + 1
                    '''
                    if retweet_count>=1:
                        tweets.append(tweet_id)
                        who_tweeted.append(user)
                    if retweet_count>max_no_of_retweet:
                        max_no_of_retweet = retweet_count


                    #print(retweet_count)
                    #print()
                #i = i + 1


                    #print(item['retweeted_status']['retweet_count'],item['created_at'])

                #i = i+1

    #print("max =%d", max_no_of_retweet)
    #print(len(tweets))
    #print(len(who_tweeted))
    #print(retweet_no_list)

    return tweets,who_tweeted

get_data_in_csv()




