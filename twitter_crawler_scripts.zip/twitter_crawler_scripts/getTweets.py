from twython import Twython
import sys

appKey = str(sys.argv[1]).rstrip()
accessToken = str(sys.argv[2]).rstrip()
filename1 = str(sys.argv[3]).rstrip()
filename2 = str(sys.argv[4]).rstrip()
twitter = Twython(appKey, access_token=accessToken)

print twitter
fileHandler1 = open(filename1,'r')
fileHandler2 = open(filename2,'a')
tweetIDs = [] # contains all the tweetID from the filename1

for line in fileHandler1:
        tweetIDs.append(int(line.split(',')[0]))
fileHandler1.close()

low = 0
high = 99
list_size = len(tweetIDs)

while low < list_size:

        id_str = ""
        for i in range(low,high):
                id_str += (str(tweetIDs[i])+',')
        id_str += (str(tweetIDs[high]))

        try:
                response =  twitter.request(endpoint = "statuses/lookup",params={'id':id_str})
                for tweet in response:
                        fileHandler2.write(str(tweet)+'\n')
                low = high + 1
                high = min(low + 99,list_size-1)
        except Exception as e:
		print e
                pass
		


fileHandler2.close()
fileHandler3.close()
