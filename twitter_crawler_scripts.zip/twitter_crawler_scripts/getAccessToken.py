import twython as tw
filename = "appDetailsTwitter.txt"
fp = open(filename,'r')
filename1 = "appDetailsTwitter_accTok.txt"
fp1 = open(filename1,'w')
for line in fp:
	list = line.split(',')
     	apiKey = list[0]
     	apiSecret = list[1].rstrip()
     	twitter = tw.Twython(apiKey,apiSecret,oauth_version=2)
	try:
		accessToken = twitter.obtain_access_token()
		print apiKey,apiSecret,"Done"
	except:
		print apiKey,apiSecret,"Error"
		continue
  	fp1.write("{0},{1},{2}\n".format(apiKey,apiSecret,accessToken))
