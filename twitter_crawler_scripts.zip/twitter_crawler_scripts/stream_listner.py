from tweepy import Stream
from tweepy.streaming import StreamListener
from twitter_client import get_client
from twitter_client import get_auth

class MyListener(StreamListener):

    def on_data(self, data):
        '''
        try:
            with open('ipl2018_may23_final_large.jsonl', 'a') as f:
                f.write(data)
                return True
        except BaseException as e:
                print("error in data: %s" % str(e))
        return True
        '''
        print(data)
        return True
    def on_error(self, status):
        print(status)
        '''
        if status == 420:
            print("rate limit exceeded")
            return False
        else:
            print(status)
            return True
        '''
auth = get_auth()
twitter_stream = Stream(auth,MyListener())
twitter_stream.filter(track = ['#ipl2018'])

        
                
